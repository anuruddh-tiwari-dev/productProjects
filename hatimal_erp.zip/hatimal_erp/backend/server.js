// const express = require("express");
// const app = express();
// require("dotenv").config();

// const vendorRoutes = require("./routes/vendorRoutes");

// // middleware
// app.use(express.json());

// // routes use
// app.use("/api", vendorRoutes);

// // // test
// // app.get("/", (req, res) => {
// //   res.send("Server Running ");
// // });

// app.listen(5000, () => {
//   console.log("Server running on port 5000");
// });







// const express = require('express');
// const cors = require('cors');
// const path = require('path');
// require("dotenv").config();

// const app = express();

// app.use(express.json());
// app.use(cors());

// // Static path for uploads
// app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// // Routes
// const vendorRoutes = require('./routes/vendorRoutes');
// const animalRoutes = require('./routes/animalRoutes');

// app.use('/api/vendors', vendorRoutes);
// app.use('/api/animals', animalRoutes);

// app.listen(5000, () => console.log('Server running on port 5000'));

const express = require('express');
const cors = require('cors');
const path = require('path');


const app = express();

app.use(express.json());
app.use(cors());

//  STATIC FOLDER (VERY IMPORTANT)
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// // routes
// const animalRoutes = require('./routes/animalRoutes');
// app.use('/api/animals', animalRoutes);


const vendorsRoutes = require('./routes/vendorRoutes');
const animalRoutes = require('./routes/animalRoutes');

app.use('/apii/vendors', vendorsRoutes);
app.use('/api/animals', animalRoutes);




// routes
const vendorRoutes = require('./routes/vendorsRoutes');
app.use('/api/vendors', vendorRoutes);

//  ERROR HANDLER (MULTER FIX)
app.use((err, req, res, next) => {
  if (err) {
    return res.status(400).json({
      error: err.message
    });
  }
  next();
});

// start
app.listen(5000, () => {
  console.log('Server running on http://localhost:5000');
});