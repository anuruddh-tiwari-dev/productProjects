const multer = require('multer');
const path = require('path');
const fs = require('fs');

//  dynamic folder (vendor wise)
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    const vendorId = req.params.vendorId;

    const dir = path.join(__dirname, `../uploads/vendor_${vendorId}`);

    // create folder if not exist
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }

    cb(null, dir);
  },

  filename: function (req, file, cb) {
    const uniqueName = Date.now() + '_' + file.fieldname + path.extname(file.originalname);
    cb(null, uniqueName);
  }
});

//  file filter (image + pdf only)
const fileFilter = (req, file, cb) => {
  const allowed = /jpg|jpeg|png|pdf/;

  const ext = allowed.test(path.extname(file.originalname).toLowerCase());
  const mime = allowed.test(file.mimetype);

  if (ext && mime) {
    cb(null, true);
  } else {
    cb(new Error('Only image/pdf allowed'));
  }
};

const upload = multer({
  storage,
  fileFilter,
  limits: { fileSize: 5 * 1024 * 1024 } // 5MB limit
});

module.exports = upload;