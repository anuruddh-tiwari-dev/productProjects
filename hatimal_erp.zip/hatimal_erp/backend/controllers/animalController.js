const db = require('../config/db');

//  SAFE NUMBER CONVERTER (NO NaN)
const toNumberOrNull = (val) => {
  if (val === undefined || val === null || val === '') return null;
  const num = Number(val);
  return isNaN(num) ? null : num;
};


// ================== CREATE ==================
exports.createAnimal = (req, res) => {
  const a = req.body;

  const filePath = req.file
    ? `${req.protocol}://${req.get('host')}/uploads/${req.file.filename}`
    : a.imageVideo || null;

  db.query(
    `INSERT INTO animals 
    (vendorId, cattleTag, category, subCategory, identityTag, displayName, liveWeight, inwardLocation, pricePerUnit, salePrice, saleStatus, payment, buyingPrice, ageMonth, color, teeth, imageVideo, paymentStatus, status) 
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
    [
      a.vendorId || null, //  FIXED (NO Number conversion)
      a.cattleTag || '',
      a.category || '',
      a.subCategory || '',
      a.identityTag || '',
      a.displayName || '',
      toNumberOrNull(a.liveWeight) ?? 0,
      a.inwardLocation || '',
      toNumberOrNull(a.pricePerUnit) ?? 0,
      toNumberOrNull(a.salePrice) ?? 0,
      a.saleStatus || 'Unsold',
      a.payment || 'Pending',
      toNumberOrNull(a.buyingPrice) ?? 0,
      toNumberOrNull(a.ageMonth) ?? 0,
      a.color || '',
      toNumberOrNull(a.teeth),
      filePath,
      a.paymentStatus || 'Pending',
      'Pending'
    ],
    (err, result) => {
      if (err) return res.status(500).json({ error: err.message });

      res.json({
        message: "Animal saved",
        id: result.insertId,
        image: filePath
      });
    }
  );
};





// ================== GET BY VENDOR ==================
exports.getAnimalsByVendor = (req, res) => {
  const vendorId = req.params.vendorId;

  db.query(
    `SELECT 
      id,
      cattleTag,
      CONCAT(category, ' > ', subCategory) AS category,
      liveWeight,
      inwardLocation,
      pricePerUnit,
      
      (liveWeight * pricePerUnit) AS salePrice,
      CASE 
        WHEN paymentStatus = 'Paid' THEN 'Sold'
        ELSE 'Unsold'
      END AS saleStatus,
      payment
      
     FROM animals 
     WHERE vendorId=?`,
    [vendorId],
    (err, rows) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json(rows);
    }
  );
};


// ================== GET BY ID ==================
exports.getAnimalById = (req, res) => {
  db.query(
    `SELECT * FROM animals WHERE id=?`,
    [req.params.id],
    (err, rows) => {
      if (err) return res.status(500).json({ error: err.message });

      if (rows.length === 0) {
        return res.status(404).json({ message: "Animal not found" });
      }

      res.json(rows[0]);
    }
  );
};


// ================== UPDATE ==================
exports.updateAnimal = (req, res) => {
  const a = req.body;

  const filePath = req.file
    ? `${req.protocol}://${req.get('host')}/uploads/${req.file.filename}`
    : undefined; // change (null nahi)

  // 1️⃣ OLD DATA LO
  db.query("SELECT * FROM animals WHERE id=?", [req.params.id], (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });

    if (rows.length === 0) {
      return res.status(404).json({ message: "Animal not found" });
    }

    const old = rows[0];

    // 2️ MERGE DATA
    const data = {
      vendorId: a.vendorId ?? old.vendorId,
      cattleTag: a.cattleTag ?? old.cattleTag,
      category: a.category ?? old.category,
      subCategory: a.subCategory ?? old.subCategory,
      identityTag: a.identityTag ?? old.identityTag,
      displayName: a.displayName ?? old.displayName,
      liveWeight: toNumberOrNull(a.liveWeight) ?? old.liveWeight,
      inwardLocation: a.inwardLocation ?? old.inwardLocation,
      pricePerUnit: toNumberOrNull(a.pricePerUnit) ?? old.pricePerUnit,
      salePrice: toNumberOrNull(a.salePrice) ?? old.salePrice,
      saleStatus: a.saleStatus ?? old.saleStatus,
      payment: a.payment ?? old.payment,
      buyingPrice: toNumberOrNull(a.buyingPrice) ?? old.buyingPrice,
      ageMonth: toNumberOrNull(a.ageMonth) ?? old.ageMonth,
      color: a.color ?? old.color,
      teeth: toNumberOrNull(a.teeth) ?? old.teeth,
      imageVideo: filePath ?? old.imageVideo, // ✅ IMPORTANT
      paymentStatus: a.paymentStatus ?? old.paymentStatus,
      status: a.status ?? old.status
    };

    // 3️ UPDATE
    db.query(
      `UPDATE animals SET 
        vendorId=?, cattleTag=?, category=?, subCategory=?, identityTag=?, displayName=?, 
        liveWeight=?, inwardLocation=?, pricePerUnit=?, salePrice=?, 
        saleStatus=?, payment=?, buyingPrice=?, ageMonth=?, color=?, teeth=?, 
        imageVideo=?, paymentStatus=?, status=? 
       WHERE id=?`,
      [
        data.vendorId,
        data.cattleTag,
        data.category,
        data.subCategory,
        data.identityTag,
        data.displayName,
        data.liveWeight,
        data.inwardLocation,
        data.pricePerUnit,
        data.salePrice,
        data.saleStatus,
        data.payment,
        data.buyingPrice,
        data.ageMonth,
        data.color,
        data.teeth,
        data.imageVideo,
        data.paymentStatus,
        data.status,
        req.params.id
      ],
      (err) => {
        if (err) return res.status(500).json({ error: err.message });

        res.json({ message: "Updated successfully" });
      }
    );
  });
};