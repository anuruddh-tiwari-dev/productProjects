const db = require('../config/db');
const fs = require('fs');
const path = require('path');

// BASIC  1
exports.createVendor = (req, res) => {
  const { vendor_type, supply_to, state, district, stores } = req.body;

  // 1. Insert vendor
  const vendorQuery = `
    INSERT INTO vendor (vendor_type, supply_to, state, district)
    VALUES (?, ?, ?, ?)
  `;

  db.query(vendorQuery, [vendor_type, supply_to, state, district], (err, result) => {
    if (err) return res.status(500).json(err);

    const vendorId = result.insertId;

    // 2. Insert multiple stores
    if (stores && stores.length > 0) {
      const storeValues = stores.map(store => [
        vendorId,
        store.name,
        store.type
      ]);

      const storeQuery = `
        INSERT INTO vendor_stores (vendor_id, store_name, store_type)
        VALUES ?
      `;

      db.query(storeQuery, [storeValues], (err2) => {
        if (err2) return res.status(500).json(err2);

        res.json({
          message: "Vendor created successfully",
          vendor_id: vendorId
        });
      });
    } else {
      res.json({
        message: "Vendor created without stores",
        vendor_id: vendorId
      });
    }
  });
};


exports.getVendor = (req, res) => {
  const id = req.params.id;

  db.query(
    `SELECT v.*, vs.store_name, vs.store_type
     FROM vendor v
     LEFT JOIN vendor_stores vs ON v.id = vs.vendor_id
     WHERE v.id = ?`,
    [id],
    (err, rows) => {
      if (err) return res.status(500).json(err);

      const vendor = {
        id: rows[0].id,
        vendor_type: rows[0].vendor_type,
        supply_to: rows[0].supply_to,
        state: rows[0].state,
        district: rows[0].district,
        stores: []
      };

      rows.forEach(r => {
        if (r.store_name) {
          vendor.stores.push({
            name: r.store_name,
            type: r.store_type
          });
        }
      });

      res.json(vendor);
    }
  );
};




exports.getVendorsByType = (req, res) => {
  const { supply_to } = req.query;

  let query = `
    SELECT v.*, vs.store_name, vs.store_type
    FROM vendor v
    LEFT JOIN vendor_stores vs ON v.id = vs.vendor_id
  `;

  const params = [];

  // filter lagana hai to
  if (supply_to) {
    query += " WHERE v.supply_to = ?";
    params.push(supply_to);
  }

  db.query(query, params, (err, rows) => {
    if (err) return res.status(500).json(err);

    const result = [];

    rows.forEach(row => {
      let vendor = result.find(v => v.id === row.id);

      if (!vendor) {
        vendor = {
          id: row.id,
          vendor_type: row.vendor_type,
          supply_to: row.supply_to,
          state: row.state,
          district: row.district,
          stores: []
        };
        result.push(vendor);
      }

      if (row.store_name) {
        vendor.stores.push({
          name: row.store_name,
          type: row.store_type
        });
      }
    });

    res.json(result);
  });
};
// ENTITY  2
exports.addEntity = (req, res) => {
  const v = req.body;

  db.query(
    `INSERT INTO vendor_entity 
    (vendor_id, authorized_person_name, entity_name, nature_of_establishment, supplier_type, cin_no, mobile, email)
    VALUES (?,?,?,?,?,?,?,?)`,
    [
      req.params.vendorId,
      v.authorized_person_name,
      v.entity_name,
      v.nature_of_establishment,
      v.supplier_type,
      v.cin_no,
      v.mobile,
      v.email
    ],
    (err) => {
      if (err) return res.status(500).json(err);
      res.json({ message: "Entity Added" });
    }
  );
};

// TAX 6
exports.addTax = (req, res) => {
  const v = req.body;

  db.query(
    `INSERT INTO vendor_tax VALUES (NULL,?,?,?,?,?)`,
    [
      req.params.vendorId,
      v.apmc_reg_no,
      v.pan_no,
      v.gst_no,
      v.import_export_code
    ],
    (err) => {
      if (err) return res.status(500).json(err);
      res.json({ message: "Tax Added" });
    }
  );
};

// BANK 7
exports.addBank = (req, res) => {
  const v = req.body;

  db.query(
    `INSERT INTO vendor_bank VALUES (NULL,?,?,?,?,?)`,
    [
      req.params.vendorId,
      v.account_no,
      v.bank_name,
      v.branch,
      v.ifsc_code
    ],
    (err) => {
      if (err) return res.status(500).json(err);
      res.json({ message: "Bank Added" });
    }
  );
};

// ADDRESS 3&4
exports.addAddress = (req, res) => {
  const v = req.body;

  db.query(
    `INSERT INTO vendor_addresses VALUES (NULL,?,?,?,?,?,?,?,?)`,
    [
      req.params.vendorId,
      v.type,
      v.building,
      v.floor,
      v.block_no,
      v.state,
      v.district,
      v.pincode
    ],
    (err) => {
      if (err) return res.status(500).json(err);
      res.json({ message: "Address Added" });
    }
  );
};

// CONTACT 5
exports.addContact = (req, res) => {
  const v = req.body;

  db.query(
    `INSERT INTO vendor_contacts VALUES (NULL,?,?,?,?,?)`,
    [
      req.params.vendorId,
      v.name,
      v.designation,
      v.mobile,
      v.email
    ],
    (err) => {
      if (err) return res.status(500).json(err);
      res.json({ message: "Contact Added" });
    }
  );
};

// DOCUMENT 8




exports.uploadKyc = async (req, res) => {
  const vendorId = req.params.vendorId;

  if (!req.files || Object.keys(req.files).length === 0) {
    return res.status(400).json({ message: "No files uploaded" });
  }

  const docMap = {
    aadhaar_front: 'aadhaar_front',
    aadhaar_back: 'aadhaar_back',
    pan_card: 'pan_card',
    photo: 'photo',
    board_resolution: 'board_resolution'
  };

  const results = [];

  try {
    for (let field in docMap) {
      if (req.files[field]) {
        const file = req.files[field][0];

        const fileUrl = `${req.protocol}://${req.get('host')}/uploads/vendor_${vendorId}/${file.filename}`;

        //  check existing
        const existing = await new Promise((resolve, reject) => {
          db.query(
            "SELECT * FROM vendor_documents WHERE vendor_id=? AND doc_type=?",
            [vendorId, docMap[field]],
            (err, result) => {
              if (err) reject(err);
              else resolve(result);
            }
          );
        });

        //  IF EXISTS → DELETE OLD + UPDATE
        if (existing.length > 0) {
          const oldUrl = existing[0].file_url;

          const oldPath = path.join(
            __dirname,
            '..',
            oldUrl.replace(`${req.protocol}://${req.get('host')}/`, '')
          );

          if (fs.existsSync(oldPath)) {
            try {
              fs.unlinkSync(oldPath);
            } catch (e) {
              console.log("Delete error", e);
            }
          }

          await new Promise((resolve, reject) => {
            db.query(
              "UPDATE vendor_documents SET file_url=? WHERE vendor_id=? AND doc_type=?",
              [fileUrl, vendorId, docMap[field]],
              (err) => {
                if (err) reject(err);
                else resolve();
              }
            );
          });

          results.push({ type: docMap[field], url: fileUrl, action: "updated" });
        }

        //  INSERT
        else {
          await new Promise((resolve, reject) => {
            db.query(
              "INSERT INTO vendor_documents (vendor_id, doc_type, file_url) VALUES (?,?,?)",
              [vendorId, docMap[field], fileUrl],
              (err) => {
                if (err) reject(err);
                else resolve();
              }
            );
          });

          results.push({ type: docMap[field], url: fileUrl, action: "inserted" });
        }
      }
    }

    res.json({
      message: "All KYC documents processed",
      files: results
    });

  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
// GET PROFILE
exports.getProfile = (req, res) => {
  const id = req.params.vendorId;

  db.query("SELECT * FROM vendor WHERE id=?", [id], (e, basic) => {
    db.query("SELECT * FROM vendor_entity WHERE vendor_id=?", [id], (e, entity) => {
      db.query("SELECT * FROM vendor_tax WHERE vendor_id=?", [id], (e, tax) => {
        db.query("SELECT * FROM vendor_bank WHERE vendor_id=?", [id], (e, bank) => {
          db.query("SELECT * FROM vendor_addresses WHERE vendor_id=?", [id], (e, address) => {
            db.query("SELECT * FROM vendor_contacts WHERE vendor_id=?", [id], (e, contact) => {
              db.query("SELECT * FROM vendor_documents WHERE vendor_id=?", [id], (e, docs) => {

                res.json({
                  basic: basic[0],
                  entity,
                  tax,
                  bank,
                  address,
                  contact,
                  documents: docs
                });

              });
            });
          });
        });
      });
    });
  });
};