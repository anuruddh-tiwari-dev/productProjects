const db = require("../config/db");

//  Create Vendor (Pending)
// exports.createVendor = (req, res) => {
//   const { name, phone, category, entity_name, location, total_animals } = req.body;

//   const sql = `INSERT INTO vendors 
//     (name, phone, category, entity_name, location, total_animals) 
//     VALUES (?, ?, ?, ?, ?, ?)`;

//   db.query(sql, [name, phone, category, entity_name, location, total_animals], (err, result) => {
//     if (err) return res.status(500).json(err);
//     res.json({ message: "Vendor Created", id: result.insertId });
//   });
// };

// //  Get All
// exports.getAllVendors = (req, res) => {
//   db.query("SELECT * FROM vendors", (err, result) => {
//     res.json(result);
//   });
// };

// //  Pending
// exports.getPending = (req, res) => {
//   db.query("SELECT * FROM vendors WHERE status='Pending'", (err, result) => {
//     res.json(result);
//   });
// };

// //  Approved
// exports.getApproved = (req, res) => {
//   db.query("SELECT * FROM vendors WHERE status='Approved'", (err, result) => {
//     res.json(result);
//   });
// };


// exports.getVendors = (req, res) => {
//   const { status, id } = req.query;

//   let sql = "SELECT * FROM vendors WHERE 1=1";
//   const values = [];

//   if (status) {
//     sql += " AND status = ?";
//     values.push(status);
//   }

//   if (id) {
//     sql += " AND id = ?";
//     values.push(id);
//   }

//   db.query(sql, values, (err, result) => {
//     if (err) {
//       return res.status(500).json({ error: err.message });
//     }
//     res.json(result);
//   });
// };


// //  Get by ID (Edit)
// exports.getVendorById = (req, res) => {
//   db.query("SELECT * FROM vendors WHERE id=?", [req.params.id], (err, result) => {
//     res.json(result[0]);
//   });
// };

// //  Update
// exports.updateVendor = (req, res) => {
//   const { name, phone, category, entity_name, location, total_animals,status } = req.body;

//   const sql = `
//     UPDATE vendors 
//     SET name=?, phone=?, category=?, entity_name=?, location=?, total_animals=?,status=?
//     WHERE id=?
//   `;

//   db.query(sql, [name, phone, category, entity_name, location, total_animals,status, req.params.id], (err) => {
//     if (err) return res.status(500).json(err);
//     res.json({ message: "Updated Successfully" });
//   });
// };

// //  Approve
// exports.approveVendor = (req, res) => {
//   db.query("UPDATE vendors SET status='Approved' WHERE id=?", [req.params.id], () => {
//     res.json({ message: "Approved" });
//   });
// };

// //  Reject
// exports.rejectVendor = (req, res) => {
//   db.query("UPDATE vendors SET status='Rejected' WHERE id=?", [req.params.id], () => {
//     res.json({ message: "Rejected" });
//   });
// };









// नया Vendor Request (POST)
exports.createVendor = (req, res) => {
  const v = req.body;
  db.query(
    "INSERT INTO vendors (vendorId,role,entityName,supplierType,state,city,pincode,authorizedPerson,contact,email,category,animals,tagFrom,tagTo,status) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
    [v.vendorId, v.role, v.entityName, v.supplierType, v.state, v.city, v.pincode, v.authorizedPerson, v.contact, v.email, v.category, v.animals, v.tagFrom, v.tagTo, "Pending"],
    (err, result) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ message: "Vendor request saved", id: result.insertId });
    }
  );
};

// Vendor Request (Pending + Rejected)
exports.getVendorRequestList = (req, res) => {
  db.query(
    "SELECT id,authorizedPerson AS name, contact, category, entityName, CONCAT(city, ', ', state) AS location, animals, status FROM vendors WHERE status IN ('Pending','Rejected')",
    (err, rows) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json(rows);
    }
  );
};

// Pending Vendor 
exports.getPendingVendors = (req, res) => {
  db.query(
    "SELECT id,authorizedPerson AS name,contact,category,entityName,city,animals,status FROM vendors WHERE status='Pending'",
    (err, rows) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json(rows);
    }
  );
};

// Approved Vendor 
exports.getApprovedVendors = (req, res) => {
  db.query(
    "SELECT id,authorizedPerson AS name,contact,category,entityName,city,animals,status FROM vendors WHERE status='Approved'",
    (err, rows) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json(rows);
    }
  );
};

// Edit Action (GET by id)

exports.getVendorById = (req, res) => {
  db.query("SELECT vendorId, role, entityName, supplierType, state, city, pincode, authorizedPerson, contact, email, category, animals, tagFrom, tagTo, status FROM vendors WHERE id=?",
    [req.params.id],
    (err, rows) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json(rows[0]);
    }
  );
};

// // Approve/Reject (PUT by id)
// exports.updateVendorStatus = (req, res) => {
//   const { status } = req.body; // "Approved" या "Rejected"
//   db.query("UPDATE vendors SET status=? WHERE id=?", [status, req.params.id], (err) => {
//     if (err) return res.status(500).json({ error: err.message });
//     res.json({ message: `Vendor ${status}` });
//   });
// };



// Approve/Reject (PUT by id + update other fields)
exports.updateVendorStatus = (req, res) => {
  const {
    role,
    entityName,
    supplierType,
    state,
    city,
    pincode,
    authorizedPerson,
    contact,
    email,
    category,
    animals,
    tagFrom,
    tagTo,
    status
  } = req.body;

  db.query(
    `UPDATE vendors 
     SET role=?, entityName=?, supplierType=?, state=?, city=?, pincode=?, 
         authorizedPerson=?, contact=?, email=?, category=?, animals=?, 
         tagFrom=?, tagTo=?, status=? 
     WHERE id=?`,
    [
      role, entityName, supplierType, state, city, pincode,
      authorizedPerson, contact, email, category, animals,
      tagFrom, tagTo, status, req.params.id
    ],
    (err, result) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ message: `Vendor ${status} and details updated successfully` });
    }
  );
};
