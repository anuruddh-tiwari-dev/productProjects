const express = require('express');
const router = express.Router();

const c = require('../controllers/vendorsController');
const upload = require('../config/vendorMulter');

router.post('/basic', c.createVendor);
router.get('/basics/:id', c.getVendor);
router.get("/", c.getVendorsByType);
router.post('/entity/:vendorId', c.addEntity);
router.post('/tax/:vendorId', c.addTax);
router.post('/bank/:vendorId', c.addBank);
router.post('/address/:vendorId', c.addAddress);
router.post('/contact/:vendorId', c.addContact);
router.post(
  '/kyc/:vendorId',
  upload.fields([
    { name: 'aadhaar_front', maxCount: 1 },
    { name: 'aadhaar_back', maxCount: 1 },
    { name: 'pan_card', maxCount: 1 },
    { name: 'photo', maxCount: 1 },
    { name: 'board_resolution', maxCount: 1 }
  ]),
  c.uploadKyc
);
router.get('/:vendorId', c.getProfile);

module.exports = router;