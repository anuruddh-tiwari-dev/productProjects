const express = require('express');
const router = express.Router();

const animalController = require('../controllers/animalController');
const upload = require('../config/multer');

// CREATE
router.post('/', upload.single('imageVideo'), animalController.createAnimal);

// UPDATE
router.put('/:id', upload.single('imageVideo'), animalController.updateAnimal);

// GET (SHORT - vendor wise)
router.get('/vendor/:vendorId', animalController.getAnimalsByVendor);

// GET (FULL - by id)
router.get('/:id', animalController.getAnimalById);

module.exports = router;