// const express = require("express");
// const router = express.Router();

// const {
//   createVendor,
//   getAllVendors,
//   getPending,
//   getApproved,
//   getVendorById,
//   updateVendor,
//   approveVendor,
//   rejectVendor,
//   getVendors
// } = require("../controllers/vendorController");

// // routes
// router.post("/vendor", createVendor);
// router.get("/vendor/request", getAllVendors);
// router.get("/vendors/pending", getPending);
// router.get("/vendors/approved", getApproved);
// // router.get("/vendors/getVendors/:status", getVendors);
// // router.get("/vendors/getVendors/:id", getVendors);
// // router.get("/vendors/getVendors", getVendors);

// router.get("/vendor/:id", getVendorById);
// router.put("/vendor/action/:id", updateVendor);

// router.put("/vendor/approve/:id", approveVendor);
// router.put("/vendor/reject/:id", rejectVendor);


// module.exports = router;


const express = require("express");
const router = express.Router();
const vendorController = require("../controllers/vendorController");

router.post("/", vendorController.createVendor);
router.get("/request", vendorController.getVendorRequestList);
router.get("/pending", vendorController.getPendingVendors);
router.get("/approved", vendorController.getApprovedVendors);
router.get("/:id", vendorController.getVendorById);
router.put("/:id/status", vendorController.updateVendorStatus);
module.exports = router;