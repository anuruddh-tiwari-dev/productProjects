const express = require("express");
const router = express.Router();

const ctrl = require("../controllers/user.controller");

router.post("/register", ctrl.registerUser);
router.post("/login", ctrl.loginUser);
router.post("/send-otp", ctrl.sendOTP);
router.post("/verify-otp", ctrl.verifyOTP);
router.post("/reset-password", ctrl.resetPassword);
router.get("/getAnimals", ctrl.getAnimals);

module.exports = router;