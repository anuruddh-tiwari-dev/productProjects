const jwt = require("jsonwebtoken");
const bcrypt = require("bcrypt");
const nodemailer = require("nodemailer");
const crypto = require("crypto");

const userModel = require("../models/user.model");

// ================= REGISTER =================
exports.registerUser = (req, res) => {
    const { username, email, password } = req.body;

    userModel.findUserByEmail(email, async (err, result) => {

        if (result.length > 0)
            return res.status(409).json({ message: "User exists" });

        const hash = await bcrypt.hash(password, 10);

        userModel.createUser(username, email, hash, (err, data) => {

            const token = jwt.sign(
                { id: data.insertId },
                process.env.JWT_SECRET,
                { expiresIn: "7d" }
            );

            res.cookie("token", token, { httpOnly: true });

            res.json({ message: "Registered" });
        });
    });
};

// ================= LOGIN =================
exports.loginUser = (req, res) => {
    const { email, password } = req.body;

    userModel.findUserByEmail(email, async (err, result) => {

        if (result.length === 0)
            return res.status(404).json({ message: "User not found" });

        const user = result[0];

        const match = await bcrypt.compare(password, user.password);

        if (!match)
            return res.status(401).json({ message: "Wrong password" });

        const token = jwt.sign(
            { id: user.id },
            process.env.JWT_SECRET,
            { expiresIn: "7d" }
        );

        res.cookie("token", token, { httpOnly: true });

        res.json({ message: "Login success" });
    });
};

// ================= SEND OTP =================
exports.sendOTP = async (req, res) => {
    const { email } = req.body;

    userModel.findUserByEmail(email, async (err, result) => {

        if (result.length === 0)
            return res.status(404).json({ message: "Email not found" });

        const otp = crypto.randomInt(1000, 9999).toString();
        const expires = Date.now() + 5 * 60 * 1000;

        // SAVE OTP
        userModel.saveOTP(email, otp, expires, () => {});

        //  PRINT OTP IN TERMINAL
        console.log(" Email:", email);
        console.log(" OTP:", otp);

        // cookie
        res.cookie("otpEmail", email, { httpOnly: true });

        let transporter = nodemailer.createTransport({
            service: "gmail",
            auth: {
                user: process.env.EMAIL_USER,
                pass: process.env.EMAIL_PASS
            }
        });

        await transporter.sendMail({
            to: email,
            subject: "OTP",
            text: `Your OTP is ${otp}`
        });

        res.json({ message: "OTP sent" });
    });
};

// ================= VERIFY OTP =================
exports.verifyOTP = (req, res) => {
    const { otp } = req.body;

    const email = req.cookies.otpEmail;

    if (!email)
        return res.status(400).json({ message: "Email missing" });

    userModel.verifyOTP(email, otp, (err, result) => {

        if (result.length === 0)
            return res.status(400).json({ message: "Invalid OTP" });

        const record = result[0];

        if (record.expires_at < Date.now())
            return res.status(400).json({ message: "Expired OTP" });

        userModel.markVerified(record.id, () => {});

        const token = jwt.sign(
            { email },
            process.env.JWT_SECRET,
            { expiresIn: "10m" }
        );

        res.cookie("resetToken", token, { httpOnly: true });

        res.json({ message: "OTP verified" });
    });
};

// ================= RESET PASSWORD =================
exports.resetPassword = async (req, res) => {
    const { newPassword, confirmPassword } = req.body;
    const token = req.cookies.resetToken;
    if (!token)
        return res.status(401).json({ message: "Unauthorized" });
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    if (newPassword !== confirmPassword)
        return res.status(400).json({ message: "Mismatch" });
    const hash = await bcrypt.hash(newPassword, 10);
    userModel.updatePassword(decoded.email, hash, () => {
        res.clearCookie("resetToken");
        res.clearCookie("otpEmail");
        res.json({ message: "Password updated" });
    });
};

// controllers/animalController.js
exports.getAnimals = (req, res) => {
    userModel.getAnimalList((err, results) => {
        if (err) {
            console.error("Database query failed:", err);
            return res.status(500).json({ error: "Database query failed" });
        }

        if (!results || results.length === 0) {
            return res.status(404).json({ message: "No animals found" });
        }

        res.json({
            message: "Animals fetched successfully",
            data: results
        });
    });
};