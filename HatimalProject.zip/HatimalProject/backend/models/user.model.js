const db = require("../config/db");

// user
exports.findUserByEmail = (email, cb) => {
    db.query("SELECT * FROM users WHERE email = ?", [email], cb);
};

exports.createUser = (username, email, password, cb) => {
    db.query(
        "INSERT INTO users (username, email, password) VALUES (?, ?, ?)",
        [username, email, password],
        cb
    );
};

exports.updatePassword = (email, password, cb) => {
    db.query(
        "UPDATE users SET password = ? WHERE email = ?",
        [password, email],
        cb
    );
};

// OTP
exports.saveOTP = (email, otp, expires, cb) => {
    db.query(
        "INSERT INTO otp_codes (email, otp, expires_at) VALUES (?, ?, ?)",
        [email, otp, expires],
        cb
    );
};

exports.verifyOTP = (email, otp, cb) => {
    db.query(
        "SELECT * FROM otp_codes WHERE email=? AND otp=? AND is_verified=FALSE",
        [email, otp],
        cb
    );
};

exports.markVerified = (id, cb) => {
    db.query(
        "UPDATE otp_codes SET is_verified=TRUE WHERE id=?",
        [id],
        cb
    );
};